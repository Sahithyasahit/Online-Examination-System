<!--Footer Starts Here-->
        <footer class="footer">
            <div class="wrapper">
                <p>
                    <a href="https://www.youtube.com/vijaythapa?sub_confirmation=1/" title="ABC Institutes">ABC Institute</a> &copy; <?php echo date('Y'); ?>. All Rights Reserved.    
                    Powered by <a href="https://www.youtube.com/vijaythapa?sub_confirmation=1" title="Vijay Thapa" target="_blank">Vijay Thapa</a>.
                </p>
            </div>
        </footer>
        <!--Footer Ends Here-->
</html>
<?php 
    define('SITEURL','http://localhost:81/quizapp/');
    define('LOCALHOST','localhost');
    define('USERNAME','root');
    define('PASSWORD','');
    define('DBNAME','quizapp');
?>